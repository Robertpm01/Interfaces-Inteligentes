using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TeletransportarCilindro : MonoBehaviour
{
    public Vector3 puntoDestino; // Fija este punto en el inspector o en el código

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.T))
        {
            transform.position = puntoDestino;
        }
    }
}
